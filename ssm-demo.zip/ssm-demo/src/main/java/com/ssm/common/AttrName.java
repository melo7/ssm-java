package com.ssm.common;

public interface AttrName {
	
	public interface Login{
		String ADMIN="admin";
	}
}
