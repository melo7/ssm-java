package com.ssm.model.error;

/**
 * 
 * 定义一标记接口，实现该接口的异常，错误处理时通过错误页面方式显示
 * @author luoxm@zjhcsoft.com 
 * @date 2013-11-22 下午1:17:00
 */
public interface IExceptionErrorPage {

}
