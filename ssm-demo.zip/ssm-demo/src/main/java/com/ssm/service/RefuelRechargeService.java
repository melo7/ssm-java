package com.ssm.service;


import java.util.List;

import com.ssm.model.CashVoucher;
import com.ssm.model.RefuelRecharge;
import com.ssm.model.Singin;




public interface RefuelRechargeService {
	
    
    List<RefuelRecharge> queryAllRefuelRecharge();
	
}
