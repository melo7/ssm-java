package com.ssm.model;


public class Insurance{
	int id;
	String insurance_id;  
	String insurance_nbr;   
	String insurance_introdu;
	String insurance_amount;  
	String insurance_endTime;   
	String insurance_status;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getInsurance_id() {
		return insurance_id;
	}
	public void setInsurance_id(String insurance_id) {
		this.insurance_id = insurance_id;
	}
	public String getInsurance_nbr() {
		return insurance_nbr;
	}
	public void setInsurance_nbr(String insurance_nbr) {
		this.insurance_nbr = insurance_nbr;
	}
	public String getInsurance_introdu() {
		return insurance_introdu;
	}
	public void setInsurance_introdu(String insurance_introdu) {
		this.insurance_introdu = insurance_introdu;
	}
	public String getInsurance_amount() {
		return insurance_amount;
	}
	public void setInsurance_amount(String insurance_amount) {
		this.insurance_amount = insurance_amount;
	}
	public String getInsurance_endTime() {
		return insurance_endTime;
	}
	public void setInsurance_endTime(String insurance_endTime) {
		this.insurance_endTime = insurance_endTime;
	}
	public String getInsurance_status() {
		return insurance_status;
	}
	public void setInsurance_status(String insurance_status) {
		this.insurance_status = insurance_status;
	}
	
}
